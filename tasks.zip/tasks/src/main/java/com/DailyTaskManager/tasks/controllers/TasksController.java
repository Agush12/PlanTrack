package com.DailyTaskManager.tasks.controllers;


import com.DailyTaskManager.tasks.domain.dto.TaskDto;
import com.DailyTaskManager.tasks.domain.dto.TaskListDto;
import com.DailyTaskManager.tasks.domain.entities.Task;
import com.DailyTaskManager.tasks.mappers.TaskMapper;
import com.DailyTaskManager.tasks.services.TaskService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/task-list/{task_list_id}/tasks")
public class TasksController {

    private final TaskService taskService;
    private final TaskMapper taskMapper;

    public TasksController(TaskService taskService, TaskMapper taskMapper) {
        this.taskService = taskService;
        this.taskMapper = taskMapper;
    }

    @GetMapping
    public List<TaskDto> listTasks(@PathVariable("task_list_id") UUID taskListid){
        return taskService.listTasks(taskListid).stream().map(taskMapper::toDto).toList();

    }
    @PostMapping
    public TaskDto createTask(@PathVariable("task_list_id") UUID taskListid,@RequestBody TaskDto taskDto){
      Task createdTask=  taskService.createTask(taskListid,taskMapper.fromDto(taskDto));

      return taskMapper.toDto(createdTask);
    }
    @GetMapping(path="/{task_id}")
    public Optional<TaskDto> getTask(@PathVariable ("task_list_id") UUID taskListid,@PathVariable("task_id")UUID taskId){
        return taskService.getTask(taskListid,taskId).map(taskMapper::toDto);

    }
    @PutMapping(path="/{task_id}")
    public TaskDto updateTask(@PathVariable ("task_list_id") UUID taskListid,@PathVariable("task_id")UUID taskId,@RequestBody TaskDto taskDto){
      Task updatedTask= taskService.updateTask(taskListid,taskId,taskMapper.fromDto(taskDto));
      return taskMapper.toDto(updatedTask);
    }

    @DeleteMapping(path="/{task_id}")
    public void deteleTask(@PathVariable ("task_list_id") UUID taskListid,@PathVariable("task_id")UUID taskId){
        taskService.deletetask(taskListid,taskId);
    }

}
