package com.DailyTaskManager.tasks.domain.dto;

public record ErrorResponse(
        int Status,
        String message,
        String detail

) {
}
