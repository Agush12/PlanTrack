package com.DailyTaskManager.tasks.domain.entities;

public enum TaskStatus {
    OPEN,CLOSED
}
