package com.DailyTaskManager.tasks.mappers;

import com.DailyTaskManager.tasks.domain.dto.TaskDto;
import com.DailyTaskManager.tasks.domain.entities.Task;
import com.DailyTaskManager.tasks.domain.entities.TaskList;

public interface TaskMapper {

    Task fromDto(TaskDto taskDto);
    TaskDto toDto(Task task);
}
