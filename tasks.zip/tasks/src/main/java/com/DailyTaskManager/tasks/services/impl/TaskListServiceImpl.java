package com.DailyTaskManager.tasks.services.impl;

import com.DailyTaskManager.tasks.domain.entities.TaskList;
import com.DailyTaskManager.tasks.repositories.TaskListRepository;
import com.DailyTaskManager.tasks.services.TaskListService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import static org.antlr.v4.runtime.tree.xpath.XPath.findAll;

@Service
public class TaskListServiceImpl implements TaskListService {
    private final TaskListRepository taskListRepository;

    public TaskListServiceImpl(TaskListRepository taskListRepository) {
        this.taskListRepository = taskListRepository;
    }

    @Override
    public List<TaskList> listTaskList() {
        return taskListRepository.findAll();
    }

    @Override
    public TaskList createTaskList(TaskList taskList) {
        if(null!=taskList.getId()){
            throw new IllegalArgumentException("Task List already has an id!");
        }
        if(taskList.getTitle()==null||taskList.getTitle().isBlank()){
            throw new IllegalArgumentException("task List title must be present!");
        }
        LocalDateTime now=LocalDateTime.now();
        return taskListRepository.save(new TaskList(null,taskList.getTitle(),taskList.getDescription(),null,now,now));
    }

    @Override
    public Optional<TaskList> getTaskList(UUID id) {
        return taskListRepository.findById(id);
    }

    @Override
    public TaskList updateTaskList(UUID taskListId, TaskList taskList) {
        if(null==taskList.getId()){
            throw new IllegalArgumentException("taskList must have an id");
        }
        if(!Objects.equals(taskList.getId(),taskListId)){
            throw new IllegalArgumentException("attempting to change taskListId");
        }
       TaskList existingTaskList= taskListRepository.findById(taskListId).orElseThrow(()->new IllegalArgumentException(("taskList not found")));
        existingTaskList.setTitle(taskList.getTitle());
        existingTaskList.setDescription(taskList.getDescription());
        existingTaskList.setUpdated(LocalDateTime.now());
       return taskListRepository.save(existingTaskList);


    }

    @Override
    public void deleteTaskList(UUID taskListId) {
        taskListRepository.deleteById(taskListId);
    }


}
