package com.DailyTaskManager.tasks.domain.entities;

public enum TaskPriority {
    HIGH,MEDIUM,LOW
}
